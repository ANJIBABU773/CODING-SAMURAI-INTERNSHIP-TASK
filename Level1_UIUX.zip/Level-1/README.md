# Level 1 — Coding Samurai Internship Projects

This folder contains the projects for Level 1.

## Projects included
- Login-Redesign
- Todo-Mobile-Mockup


### Coding Samurai — Core Offerings
- **Technical Internships & Training** — mentor-led, hands-on projects across web development, data science, machine learning, game development, UI/UX, and more.  
- **IT Services**  
  - *Website Development* — responsive, high-performance websites.  
  - *Mobile App Development* — iOS & Android apps with intuitive UX.  
  - *UI/UX Design* — research-driven interface & interaction design.  
  - *Graphic Design* — branding, marketing assets, and visuals.  
  - *Video Editing* — promotional and demo videos.  
- **IT Consultancy** — technology strategy, process optimization, and bespoke solutions to improve efficiency and growth.

